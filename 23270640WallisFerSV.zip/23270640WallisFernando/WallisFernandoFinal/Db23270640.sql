
CREATE TABLE IF NOT EXISTS Categorias (
    id_categoria INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255),
    descripcion TEXT
);

CREATE TABLE IF NOT EXISTS Proveedores (
    id_proveedor VARCHAR(50) PRIMARY KEY,
    nombre VARCHAR(255),
    num_celular VARCHAR(20),
    contacto VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS Clientes (
    id_cliente VARCHAR(50) PRIMARY KEY,
    nombre VARCHAR(255),
    telefono VARCHAR(20),
    direccion TEXT
);

-- Tablas principales
CREATE TABLE IF NOT EXISTS Categorias (
    id_categoria INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255),
    descripcion TEXT
);

CREATE TABLE IF NOT EXISTS Proveedores (
    id_proveedor VARCHAR(50) PRIMARY KEY,
    nombre VARCHAR(255),
    num_celular VARCHAR(20),
    contacto VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS Clientes (
    id_cliente VARCHAR(50) PRIMARY KEY,
    nombre VARCHAR(255),
    telefono VARCHAR(20),
    direccion TEXT
);

CREATE TABLE IF NOT EXISTS Empleados (
    id_empleado VARCHAR(50) PRIMARY KEY,
    nombre VARCHAR(255),
    puesto VARCHAR(255),
    num_celular VARCHAR(20)
);

CREATE TABLE IF NOT EXISTS Productos (
    codigo VARCHAR(50) PRIMARY KEY,
    nombre VARCHAR(255),
    precio DECIMAL(10,2),
    costo DECIMAL(10,2),
    existencias INT,
    id_categoria VARCHAR(50),
    id_proveedor VARCHAR(50),
    id_unidad VARCHAR(50),
    fecha_vencimiento DATE
);

-- Compras y detalle
CREATE TABLE IF NOT EXISTS Compras (
    id_compra INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATETIME,
    id_proveedor VARCHAR(50),
    total DECIMAL(10,2),
    FOREIGN KEY (id_proveedor) REFERENCES Proveedores(id_proveedor)
);

CREATE TABLE IF NOT EXISTS DetalleCompras (
    id_detalle INT AUTO_INCREMENT PRIMARY KEY,
    id_compra INT,
    codigo_producto VARCHAR(50),
    cantidad INT,
    costo_unitario DECIMAL(10,2),
    FOREIGN KEY (id_compra) REFERENCES Compras(id_compra),
    FOREIGN KEY (codigo_producto) REFERENCES Productos(codigo)
);

-- Ventas y detalle
CREATE TABLE IF NOT EXISTS Ventas (
    id_venta INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATETIME,
    id_cliente VARCHAR(50),
    id_empleado VARCHAR(50),
    total DECIMAL(10,2),
    metodo_pago VARCHAR(50),
    FOREIGN KEY (id_cliente) REFERENCES Clientes(id_cliente),
    FOREIGN KEY (id_empleado) REFERENCES Empleados(id_empleado)
);

CREATE TABLE IF NOT EXISTS DetalleVentas (
    id_detalle INT AUTO_INCREMENT PRIMARY KEY,
    id_venta INT,
    codigo_producto VARCHAR(50),
    cantidad INT,
    precio_unitario DECIMAL(10,2),
    FOREIGN KEY (id_venta) REFERENCES Ventas(id_venta),
    FOREIGN KEY (codigo_producto) REFERENCES Productos(codigo)
);

