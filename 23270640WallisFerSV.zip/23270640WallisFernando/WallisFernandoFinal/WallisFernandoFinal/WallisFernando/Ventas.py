from tkinter import Label, Entry, messagebox
from base import VentanaBase
from conexion_bd import conectar

class VentanaVentas(VentanaBase):
    def __init__(self, siguiente_ventana=None, id_venta=None):
        super().__init__("Registro de Ventas - Abarrotes Wallis", siguiente_ventana)
        self.id_venta = id_venta

        campos = [
            ("id_venta",   "ID Venta"),
            ("fecha",      "Fecha"),
            ("importe",    "Importe"),
            ("id_cliente", "ID Cliente"),
            ("id_empleado","ID Empleado")
        ]

        for i, (clave, texto) in enumerate(campos):
            lbl = Label(self.frame, text=texto)
            lbl.grid(row=i, column=0, padx=10, pady=5)
            ent = Entry(self.frame, bg="plum")
            ent.grid(row=i, column=1, padx=10, pady=5)
            self.entradas[clave] = ent

        if self.id_venta:
            self._cargar_venta()

    def _cargar_venta(self):
        try:
            conn = conectar()
            cur = conn.cursor()
            cur.execute("""
                SELECT fecha, importe, id_cliente, id_empleado
                  FROM Ventas WHERE id_venta = ?
            """, (self.id_venta,))
            fila = cur.fetchone()
            conn.close()
            if fila:
                keys = ["fecha", "importe", "id_cliente", "id_empleado"]
                for key, val in zip(keys, fila):
                    self.entradas[key].insert(0, str(val))
                self.entradas["id_venta"].insert(0, self.id_venta)
                self.entradas["id_venta"].config(state="disabled")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo cargar la venta:\n{e}")

    def guardar_y_continuar(self):
        datos = {k: self.entradas[k].get().strip() for k in self.entradas}

        if not datos["id_venta"] or not datos["fecha"]:
            messagebox.showerror("Error", "ID Venta y Fecha son obligatorios")
            return

        try:
            imp = float(datos["importe"]) if datos["importe"] else None
        except ValueError:
            messagebox.showerror("Error", "Importe debe ser numérico")
            return

        try:
            conn = conectar()
            cur = conn.cursor()

            cur.execute("""
                CREATE TABLE IF NOT EXISTS Ventas (
                    id_venta TEXT PRIMARY KEY,
                    fecha TEXT,
                    importe REAL,
                    id_cliente TEXT,
                    id_empleado TEXT
                )
            """)

            if self.id_venta:
                cur.execute("""
                    UPDATE Ventas
                       SET fecha      = ?,
                           importe    = ?,
                           id_cliente = ?,
                           id_empleado= ?
                     WHERE id_venta   = ?
                """, (datos["fecha"], imp, datos["id_cliente"], datos["id_empleado"], self.id_venta))
                msg = "Venta actualizada correctamente."
            else:
                cur.execute("""
                    INSERT INTO Ventas (id_venta, fecha, importe, id_cliente, id_empleado)
                    VALUES (?, ?, ?, ?, ?)
                """, (datos["id_venta"], datos["fecha"], imp, datos["id_cliente"], datos["id_empleado"]))
                msg = "Venta registrada correctamente."

            conn.commit()
            conn.close()
            messagebox.showinfo("Éxito", msg)
            self.abrir_siguiente_ventana()

        except Exception as e:
            messagebox.showerror("Error", f"No se pudo guardar la venta:\n{e}")
