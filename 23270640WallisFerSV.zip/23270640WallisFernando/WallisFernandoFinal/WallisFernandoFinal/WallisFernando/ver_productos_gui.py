from tkinter import Label, Listbox, Scrollbar, Button, END, messagebox
from base import VentanaBase
from conexion_bd import conectar
from Productos import VentanaProductos

class VentanaVerProductos(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Productos Registrados - Abarrotes Wallis", siguiente_ventana)
        self.geometry("800x450")

        Label(self, text="Listado de Productos", font=("Arial", 14, "bold")).pack(pady=10)

        scroll = Scrollbar(self)
        scroll.pack(side="right", fill="y")
        self.lista = Listbox(self, font=("Consolas", 10), yscrollcommand=scroll.set)
        self.lista.pack(padx=20, pady=10, fill="both", expand=True)
        scroll.config(command=self.lista.yview)

        btn_frame = Label(self)
        btn_frame.pack(pady=5)
        Button(btn_frame, text="Refrescar", command=self.cargar_productos).grid(row=0, column=0, padx=5)
        Button(btn_frame, text="Editar",    command=self._editar).grid(row=0, column=1, padx=5)
        Button(btn_frame, text="Eliminar",  command=self._eliminar).grid(row=0, column=2, padx=5)

        self.cargar_productos()

    def cargar_productos(self):
        self.lista.delete(0, END)
        try:
            conn = conectar()
            cur  = conn.cursor()
            cur.execute("""
                SELECT codigo, nombre, precio, costo, existencias,
                       id_categoria, id_proveedor, id_unidad, fecha_vencimiento
                  FROM Productos
            """)
            self.registros = cur.fetchall()
            conn.close()

            if not self.registros:
                self.lista.insert(END, "No hay productos registrados.")
                return

            header = (f"{'Código':<10}{'Nombre':<20}{'Precio':<10}"
                      f"{'Costo':<10}{'Exist.':<8}{'Cat.':<8}{'Prov.':<8}{'Uni.':<8}{'Venc.'}")
            self.lista.insert(END, header)
            self.lista.insert(END, "-"*100)

            for p in self.registros:
                imp  = f"{p[2]:.2f}" if p[2] is not None else "0.00"
                cost = f"{p[3]:.2f}" if p[3] is not None else "0.00"
                linea = (f"{p[0]:<10}{p[1]:<20}{imp:<10}"
                         f"{cost:<10}{p[4]:<8}{p[5]:<8}{p[6]:<8}{p[7]:<8}{p[8]}")
                self.lista.insert(END, linea)
        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron cargar datos:\n{e}")

    def _editar(self):
        sel = self.lista.curselection()
        if not sel or sel[0] < 2:
            messagebox.showwarning("Seleccionar", "Selecciona un producto válido.")
            return
        idx   = sel[0] - 2
        codigo= self.registros[idx][0]
        self.destroy()
        VentanaProductos(None, codigo=codigo).mainloop()

    def _eliminar(self):
        sel = self.lista.curselection()
        if not sel or sel[0] < 2:
            messagebox.showwarning("Seleccionar", "Selecciona un producto válido.")
            return
        idx    = sel[0] - 2
        codigo = self.registros[idx][0]
        nombre = self.registros[idx][1]
        if not messagebox.askyesno("Confirmar", f"Eliminar producto '{nombre}'?"):
            return
        try:
            conn = conectar()
            cur  = conn.cursor()
            cur.execute("DELETE FROM Productos WHERE codigo = ?", (codigo,))
            conn.commit(); conn.close()
            messagebox.showinfo("Éxito", "Producto eliminado.")
            self.cargar_productos()
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo eliminar:\n{e}")

if __name__ == "__main__":
    VentanaVerProductos().mainloop()
