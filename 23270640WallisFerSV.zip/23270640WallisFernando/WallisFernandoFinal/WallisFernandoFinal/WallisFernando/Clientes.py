from tkinter import Label, Entry, messagebox
from base import VentanaBase
from conexion_bd import conectar

class VentanaClientes(VentanaBase):
    def __init__(self, siguiente_ventana=None, id_cliente=None):
        super().__init__("Registro de Clientes - Abarrotes Wallis", siguiente_ventana)
        self.id_cliente = id_cliente

        campos = [
            ("id_cliente", "ID Cliente"),
            ("nombre",     "Nombre"),
            ("telefono",   "Teléfono"),
            ("direccion",  "Dirección")
        ]

        for i, (clave, texto) in enumerate(campos):
            lbl = Label(self.frame, text=texto)
            lbl.grid(row=i, column=0, padx=10, pady=5)
            entry = Entry(self.frame, bg="peachpuff")
            entry.grid(row=i, column=1, padx=10, pady=5)
            self.entradas[clave] = entry

        if self.id_cliente:
            self._cargar_cliente()

    def _cargar_cliente(self):
        try:
            conn = conectar()
            cur  = conn.cursor()
            cur.execute("SELECT nombre, telefono, direccion FROM Clientes WHERE id_cliente = ?", (self.id_cliente,))
            fila = cur.fetchone()
            conn.close()
            if fila:
                self.entradas["nombre"].insert(0, fila[0])
                self.entradas["telefono"].insert(0, fila[1])
                self.entradas["direccion"].insert(0, fila[2])
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo cargar cliente:\n{e}")

    def guardar_y_continuar(self):
        idc       = self.entradas["id_cliente"].get().strip()
        nombre    = self.entradas["nombre"].get().strip()
        telefono  = self.entradas["telefono"].get().strip()
        direccion = self.entradas["direccion"].get().strip()

        if not idc or not nombre:
            messagebox.showerror("Error", "ID Cliente y Nombre son obligatorios")
            return

        try:
            conn = conectar()
            cur  = conn.cursor()
            cur.execute("""
                CREATE TABLE IF NOT EXISTS Clientes (
                    id_cliente TEXT PRIMARY KEY,
                    nombre TEXT,
                    telefono TEXT,
                    direccion TEXT
                )
            """)

            if self.id_cliente:
                cur.execute("""
                    UPDATE Clientes
                       SET nombre   = ?,
                           telefono = ?,
                           direccion= ?
                     WHERE id_cliente = ?
                """, (nombre, telefono, direccion, self.id_cliente))
                msg = "Cliente actualizado correctamente."
            else:
                cur.execute("""
                    INSERT INTO Clientes (id_cliente, nombre, telefono, direccion)
                    VALUES (?, ?, ?, ?)
                """, (idc, nombre, telefono, direccion))
                msg = "Cliente registrado correctamente."

            conn.commit()
            conn.close()

            messagebox.showinfo("Éxito", msg)
            self.abrir_siguiente_ventana()

        except Exception as e:
            messagebox.showerror("Error", f"No se pudo guardar cliente:\n{e}")
