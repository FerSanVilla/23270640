from tkinter import Label, Entry, messagebox
from base import VentanaBase
from conexion_bd import conectar

class VentanaProveedores(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Gestión de Proveedores - Abarrotes Wallis", siguiente_ventana)

        campos = [
            ("id_proveedor", "ID Proveedor"),
            ("nombre", "Nombre"),
            ("num_celular", "Número Celular"),
            ("contacto", "Contacto")
        ]

        for i, (clave, texto) in enumerate(campos):
            lbl = Label(self.frame, text=texto)
            lbl.grid(row=i, column=0, padx=10, pady=5)
            ent = Entry(self.frame, bg="lightgreen")
            ent.grid(row=i, column=1, padx=10, pady=5)
            self.entradas[clave] = ent

    def guardar_y_continuar(self):
        if not self.entradas["id_proveedor"].get() or not self.entradas["nombre"].get():
            messagebox.showerror("Error", "ID y Nombre son obligatorios")
            return

        try:
            conexion = conectar()
            cursor = conexion.cursor()

            cursor.execute("""
                CREATE TABLE IF NOT EXISTS Proveedores (
                    id_proveedor TEXT PRIMARY KEY,
                    nombre TEXT,
                    num_celular TEXT,
                    contacto TEXT
                )
            """)

            cursor.execute("""
                INSERT INTO Proveedores (id_proveedor, nombre, num_celular, contacto)
                VALUES (?, ?, ?, ?)
            """, (
                self.entradas["id_proveedor"].get(),
                self.entradas["nombre"].get(),
                self.entradas["num_celular"].get(),
                self.entradas["contacto"].get()
            ))

            conexion.commit()
            conexion.close()

            messagebox.showinfo("Éxito", "Proveedor guardado correctamente")
            self.abrir_siguiente_ventana()

        except Exception as e:
            messagebox.showerror("Error", f"No se pudo guardar el proveedor:\n{e}")
