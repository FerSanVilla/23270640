from tkinter import Label, Listbox, Scrollbar, Button, END, messagebox
from base import VentanaBase
from conexion_bd import conectar
from Proveedores import VentanaProveedores

class VentanaVerProveedores(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Proveedores Registrados - Abarrotes Wallis", siguiente_ventana)
        self.geometry("600x450")

        Label(self, text="Listado de Proveedores", font=("Arial", 14, "bold")).pack(pady=10)

        scroll = Scrollbar(self)
        scroll.pack(side="right", fill="y")
        self.lista = Listbox(self, font=("Consolas", 12), yscrollcommand=scroll.set)
        self.lista.pack(padx=20, pady=10, fill="both", expand=True)
        scroll.config(command=self.lista.yview)

        btn_frame = Label(self)
        btn_frame.pack(pady=5)
        Button(btn_frame, text="Refrescar", command=self.cargar_proveedores).grid(row=0, column=0, padx=5)
        Button(btn_frame, text="Editar",    command=self._editar).grid(row=0, column=1, padx=5)
        Button(btn_frame, text="Eliminar",  command=self._eliminar).grid(row=0, column=2, padx=5)

        self.cargar_proveedores()

    def cargar_proveedores(self):
        self.lista.delete(0, END)
        try:
            conn = conectar()
            cur  = conn.cursor()
            cur.execute("SELECT id_proveedor, nombre, num_celular, contacto FROM Proveedores")
            self.registros = cur.fetchall()
            conn.close()

            if not self.registros:
                self.lista.insert(END, "No hay proveedores registrados.")
                return

            header = f"{'ID':<15}{'Nombre':<20}{'Celular':<15}{'Contacto'}"
            self.lista.insert(END, header)
            self.lista.insert(END, "-"*70)

            for prov in self.registros:
                linea = f"{prov[0]:<15}{prov[1]:<20}{prov[2]:<15}{prov[3]}"
                self.lista.insert(END, linea)

        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron cargar los datos:\n{e}")

    def _editar(self):
        sel = self.lista.curselection()
        if not sel or sel[0] < 2:
            messagebox.showwarning("Seleccionar", "Selecciona un proveedor válido.")
            return
        idx = sel[0] - 2
        pid = self.registros[idx][0]
        self.destroy()
        VentanaProveedores(None, id_proveedor=pid).mainloop()

    def _eliminar(self):
        sel = self.lista.curselection()
        if not sel or sel[0] < 2:
            messagebox.showwarning("Seleccionar", "Selecciona un proveedor válido.")
            return
        idx = sel[0] - 2
        pid    = self.registros[idx][0]
        nombre = self.registros[idx][1]
        if not messagebox.askyesno("Confirmar", f"Eliminar proveedor '{nombre}'?"):
            return
        try:
            conn = conectar()
            cur  = conn.cursor()
            cur.execute("DELETE FROM Proveedores WHERE id_proveedor = ?", (pid,))
            conn.commit()
            conn.close()
            messagebox.showinfo("Éxito", "Proveedor eliminado.")
            self.cargar_proveedores()
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo eliminar:\n{e}")

if __name__ == "__main__":
    VentanaVerProveedores().mainloop()
