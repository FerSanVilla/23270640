from tkinter import Label, Listbox, Scrollbar, Button, END, messagebox
from base import VentanaBase
from conexion_bd import conectar
from compras import VentanaCompras

class VentanaVerCompras(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Compras Registradas - Abarrotes Wallis", siguiente_ventana)
        self.geometry("700x450")

        Label(self, text="Listado de Compras", font=("Arial", 14, "bold")).pack(pady=10)

        scroll = Scrollbar(self)
        scroll.pack(side="right", fill="y")
        self.lista = Listbox(self, font=("Consolas", 12), yscrollcommand=scroll.set)
        self.lista.pack(padx=20, pady=10, fill="both", expand=True)
        scroll.config(command=self.lista.yview)

        # Botones
        btn_frame = Label(self)
        btn_frame.pack(pady=5)
        Button(btn_frame, text="Refrescar", command=self.cargar_compras).grid(row=0, column=0, padx=5)
        Button(btn_frame, text="Editar",    command=self._editar).grid(row=0, column=1, padx=5)
        Button(btn_frame, text="Eliminar",  command=self._eliminar).grid(row=0, column=2, padx=5)

        self.cargar_compras()

    def cargar_compras(self):
        self.lista.delete(0, END)
        try:
            conn = conectar(); cur = conn.cursor()
            cur.execute("SELECT id_compra, id_proveedor, fecha, importe FROM compras")
            self.registros = cur.fetchall()
            conn.close()

            if not self.registros:
                self.lista.insert(END, "No hay compras registradas.")
                return

            header = f"{'ID Compra':<15}{'Proveedor':<15}{'Fecha':<15}{'Importe'}"
            self.lista.insert(END, header)
            self.lista.insert(END, "-" * 65)
            for c in self.registros:
                importe = f"{c[3]:.2f}" if c[3] is not None else "0.00"
                linea = f"{c[0]:<15}{c[1]:<15}{c[2]:<15}{importe}"
                self.lista.insert(END, linea)

        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron cargar los datos:\n{e}")

    def _editar(self):
        sel = self.lista.curselection()
        if not sel or sel[0] < 2:
            messagebox.showwarning("Seleccionar", "Selecciona una compra válida.")
            return
        idx = sel[0] - 2
        idc = self.registros[idx][0]
        self.destroy()
        VentanaCompras(None, id_compra=idc).mainloop()

    def _eliminar(self):
        sel = self.lista.curselection()
        if not sel or sel[0] < 2:
            messagebox.showwarning("Seleccionar", "Selecciona una compra válida.")
            return
        idx = sel[0] - 2
        idc = self.registros[idx][0]
        prov = self.registros[idx][1]
        if not messagebox.askyesno("Confirmar", f"Eliminar compra '{idc}'?"):
            return
        try:
            conn = conectar(); cur = conn.cursor()
            cur.execute("DELETE FROM compras WHERE id_compra = ?", (idc,))
            conn.commit(); conn.close()
            messagebox.showinfo("Éxito", "Compra eliminada.")
            self.cargar_compras()
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo eliminar:\n{e}")

if __name__ == "__main__":
    VentanaVerCompras().mainloop()

