from tkinter import Label, Entry, messagebox
from base import VentanaBase
from conexion_bd import conectar

class VentanaCompras(VentanaBase):
    def __init__(self, siguiente_ventana=None, id_compra=None):
        super().__init__("Registro de Compras - Abarrotes Wallis", siguiente_ventana)
        self.id_compra = id_compra

        campos = [
            ("id_compra", "ID Compra"),
            ("id_proveedor", "ID Proveedor"),
            ("fecha", "Fecha"),
            ("importe", "Importe")
        ]

        for i, (clave, texto) in enumerate(campos):
            lbl = Label(self.frame, text=texto)
            lbl.grid(row=i, column=0, padx=10, pady=5)
            entry = Entry(self.frame, bg="lightyellow")
            entry.grid(row=i, column=1, padx=10, pady=5)
            self.entradas[clave] = entry

        if self.id_compra:
            self._cargar_compra()

    def _cargar_compra(self):
        try:
            conn = conectar()
            cur = conn.cursor()
            cur.execute("SELECT id_proveedor, fecha, importe FROM compras WHERE id_compra = ?", (self.id_compra,))
            fila = cur.fetchone()
            conn.close()
            if fila:
                self.entradas["id_proveedor"].insert(0, fila[0])
                self.entradas["fecha"].insert(0, fila[1])
                self.entradas["importe"].insert(0, str(fila[2]))
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo cargar la compra:\n{e}")

    def guardar_y_continuar(self):
        idc = self.entradas["id_compra"].get().strip()
        prov = self.entradas["id_proveedor"].get().strip()
        fecha = self.entradas["fecha"].get().strip()
        imp = self.entradas["importe"].get().strip()

        if not idc or not prov or not fecha:
            messagebox.showerror("Error", "ID Compra, Proveedor y Fecha son obligatorios")
            return

        try:
            importe = float(imp) if imp else None
        except ValueError:
            messagebox.showerror("Error", "El importe debe ser numérico")
            return

        try:
            conn = conectar()
            cur = conn.cursor()

            cur.execute("""
                CREATE TABLE IF NOT EXISTS compras (
                    id_compra TEXT PRIMARY KEY,
                    id_proveedor TEXT,
                    fecha TEXT,
                    importe REAL
                )
            """)

            if self.id_compra:
                cur.execute("""
                    UPDATE compras
                       SET id_proveedor = ?,
                           fecha        = ?,
                           importe      = ?
                     WHERE id_compra    = ?
                """, (prov, fecha, importe, self.id_compra))
                msg = "Compra actualizada correctamente."
            else:
                cur.execute("""
                    INSERT INTO compras (id_compra, id_proveedor, fecha, importe)
                    VALUES (?, ?, ?, ?)
                """, (idc, prov, fecha, importe))
                msg = "Compra registrada correctamente."

            conn.commit()
            conn.close()
            messagebox.showinfo("Éxito", msg)
            self.abrir_siguiente_ventana()

        except Exception as e:
            messagebox.showerror("Error", f"No se pudo guardar la compra:\n{e}")
