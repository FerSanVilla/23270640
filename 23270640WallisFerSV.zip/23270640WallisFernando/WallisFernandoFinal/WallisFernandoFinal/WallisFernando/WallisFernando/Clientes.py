from tkinter import Label, Entry, messagebox
from base import VentanaBase

class VentanaClientes(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Registro de Clientes - Abarrotes Wallis", siguiente_ventana)

        campos = [
            ("id_cliente", "ID Cliente"),
            ("nombre", "Nombre"),
            ("telefono", "Teléfono"),
            ("direccion", "Dirección")
        ]

        for i, (clave, texto) in enumerate(campos):
            lbl = Label(self, text=texto)
            lbl.place(x=20, y=50 + i*40, width=100, height=20)
            self.entradas[clave] = Entry(self, bg="peachpuff")
            self.entradas[clave].place(x=130, y=50 + i*40, width=300, height=20)

    def guardar_y_continuar(self):
        if not self.entradas["id_cliente"].get() or not self.entradas["nombre"].get():
            messagebox.showerror("Error", "ID Cliente y Nombre son obligatorios")
            return
        messagebox.showinfo("Éxito", "Cliente registrado correctamente")
        self.abrir_siguiente_ventana()
