from tkinter import Label, Entry, messagebox
from base import VentanaBase

class VentanaCompras(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Registro de Compras - Abarrotes Wallis", siguiente_ventana)

        campos = [
            ("id_compra", "ID Compra"),
            ("id_proveedor", "ID Proveedor"),
            ("fecha", "Fecha"),
            ("importe", "Importe")
        ]

        for i, (clave, texto) in enumerate(campos):
            lbl = Label(self, text=texto)
            lbl.place(x=20, y=50 + i*40, width=100, height=20)
            self.entradas[clave] = Entry(self, bg="lightyellow")
            self.entradas[clave].place(x=130, y=50 + i*40, width=200, height=20)

    def guardar_y_continuar(self):
        try:
            if not self.entradas["id_compra"].get() or not self.entradas["id_proveedor"].get():
                messagebox.showerror("Error", "ID Compra e ID Proveedor son obligatorios")
                return
            if self.entradas["importe"].get():
                float(self.entradas["importe"].get())
            messagebox.showinfo("Éxito", "Compra registrada correctamente")
            self.abrir_siguiente_ventana()
        except ValueError:
            messagebox.showerror("Error", "El importe debe ser un número válido")
