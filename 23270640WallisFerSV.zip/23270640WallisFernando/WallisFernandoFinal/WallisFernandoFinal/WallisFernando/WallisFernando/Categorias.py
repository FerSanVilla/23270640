from tkinter import Label, Entry, messagebox
from base import VentanaBase

class VentanaCategorias(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Catálogo de Categorías - Abarrotes Wallis", siguiente_ventana)
        
        lblIdcategoria = Label(self, text="ID Categoría")
        lblIdcategoria.place(x=20, y=50, width=100, height=20)
        self.entradas["id_categoria"] = Entry(self, bg="pink")
        self.entradas["id_categoria"].place(x=130, y=50, width=200, height=20)
        
        lblNombre = Label(self, text="Nombre")
        lblNombre.place(x=20, y=90, width=100, height=20)
        self.entradas["nombre"] = Entry(self, bg="pink")
        self.entradas["nombre"].place(x=130, y=90, width=200, height=20)
    
    def guardar_y_continuar(self):
        if not self.entradas["id_categoria"].get() or not self.entradas["nombre"].get():
            messagebox.showerror("Error", "Todos los campos son obligatorios")
            return
        
        messagebox.showinfo("Éxito", "Categoría guardada correctamente")
        self.abrir_siguiente_ventana()
