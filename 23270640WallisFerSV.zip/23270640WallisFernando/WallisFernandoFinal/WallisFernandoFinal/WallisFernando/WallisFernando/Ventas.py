from tkinter import Label, Entry, messagebox
from base import VentanaBase

class VentanaVentas(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Registro de Ventas - Abarrotes Wallis", siguiente_ventana)

        campos = [
            ("id_venta", "ID Venta"),
            ("fecha", "Fecha"),
            ("importe", "Importe"),
            ("id_cliente", "ID Cliente"),
            ("id_empleado", "ID Empleado")
        ]

        for i, (clave, texto) in enumerate(campos):
            lbl = Label(self, text=texto)
            lbl.place(x=20, y=50 + i*40, width=100, height=20)
            self.entradas[clave] = Entry(self, bg="plum")
            self.entradas[clave].place(x=130, y=50 + i*40, width=200, height=20)

    def guardar_y_continuar(self):
        try:
            if not self.entradas["id_venta"].get() or not self.entradas["fecha"].get():
                messagebox.showerror("Error", "ID Venta y Fecha son obligatorios")
                return
            if self.entradas["importe"].get():
                float(self.entradas["importe"].get())
            messagebox.showinfo("Éxito", "Venta registrada correctamente")
            self.abrir_siguiente_ventana()
        except ValueError:
            messagebox.showerror("Error", "El importe debe ser un número válido")
