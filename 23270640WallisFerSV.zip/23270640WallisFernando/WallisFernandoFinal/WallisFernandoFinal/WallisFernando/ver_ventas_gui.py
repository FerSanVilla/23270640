from tkinter import Label, Listbox, Scrollbar, Button, END, messagebox
from base import VentanaBase
from conexion_bd import conectar
from Ventas import VentanaVentas

class VentanaVerVentas(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Ventas Registradas - Abarrotes Wallis", siguiente_ventana)
        self.geometry("700x450")

        Label(self, text="Listado de Ventas", font=("Arial", 14, "bold")).pack(pady=10)

        scroll = Scrollbar(self)
        scroll.pack(side="right", fill="y")
        self.lista = Listbox(self, font=("Consolas", 12), yscrollcommand=scroll.set)
        self.lista.pack(padx=20, pady=10, fill="both", expand=True)
        scroll.config(command=self.lista.yview)

        btn_frame = Label(self)
        btn_frame.pack(pady=5)
        Button(btn_frame, text="Refrescar", command=self.cargar_ventas).grid(row=0, column=0, padx=5)
        Button(btn_frame, text="Editar",    command=self._editar).grid(row=0, column=1, padx=5)
        Button(btn_frame, text="Eliminar",  command=self._eliminar).grid(row=0, column=2, padx=5)

        self.cargar_ventas()

    def cargar_ventas(self):
        self.lista.delete(0, END)
        try:
            conn = conectar(); cur = conn.cursor()
            cur.execute("SELECT id_venta, fecha, importe, id_cliente, id_empleado FROM Ventas")
            self.registros = cur.fetchall()
            conn.close()

            if not self.registros:
                self.lista.insert(END, "No hay ventas registradas.")
                return

            header = f"{'ID Venta':<15}{'Fecha':<15}{'Importe':<15}{'ID Cliente':<15}{'ID Empleado'}"
            self.lista.insert(END, header)
            self.lista.insert(END, "-"*80)

            for v in self.registros:
                imp = f"{v[2]:.2f}" if v[2] is not None else "0.00"
                linea = f"{v[0]:<15}{v[1]:<15}{imp:<15}{v[3]:<15}{v[4]}"
                self.lista.insert(END, linea)

        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron cargar los datos:\n{e}")

    def _editar(self):
        sel = self.lista.curselection()
        if not sel or sel[0] < 2:
            messagebox.showwarning("Seleccionar", "Selecciona una venta válida.")
            return
        idx     = sel[0] - 2
        vid     = self.registros[idx][0]
        self.destroy()
        VentanaVentas(None, id_venta=vid).mainloop()

    def _eliminar(self):
        sel = self.lista.curselection()
        if not sel or sel[0] < 2:
            messagebox.showwarning("Seleccionar", "Selecciona una venta válida.")
            return
        idx = sel[0] - 2
        vid = self.registros[idx][0]
        fech= self.registros[idx][1]
        if not messagebox.askyesno("Confirmar", f"Eliminar venta '{vid}' de {fech}?"):
            return
        try:
            conn = conectar(); cur = conn.cursor()
            cur.execute("DELETE FROM Ventas WHERE id_venta = ?", (vid,))
            conn.commit(); conn.close()
            messagebox.showinfo("Éxito", "Venta eliminada.")
            self.cargar_ventas()
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo eliminar:\n{e}")

if __name__ == "__main__":
    VentanaVerVentas().mainloop()
