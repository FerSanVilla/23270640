import sqlite3

def crear_tablas():
    conexion = sqlite3.connect("willis.db")
    cursor = conexion.cursor()

    # Tabla Categorias
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Categorias (
            id_categoria INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT,
            descripcion TEXT
        )
    """)

    # Tabla Proveedores
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Proveedores (
            id_proveedor TEXT PRIMARY KEY,
            nombre TEXT,
            num_celular TEXT,
            contacto TEXT
        )
    """)

    # Tabla Clientes
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Clientes (
            id_cliente TEXT PRIMARY KEY,
            nombre TEXT,
            telefono TEXT,
            direccion TEXT
        )
    """)

    # Tabla Empleados
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Empleados (
            id_empleado TEXT PRIMARY KEY,
            nombre TEXT,
            puesto TEXT,
            num_celular TEXT
        )
    """)

    # Tabla Productos
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Productos (
            codigo TEXT PRIMARY KEY,
            nombre TEXT,
            precio REAL,
            costo REAL,
            existencias INTEGER,
            id_categoria TEXT,
            id_proveedor TEXT,
            id_unidad TEXT,
            fecha_vencimiento TEXT
        )
    """)

    # Tabla Compras
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS compras (
            id_compra TEXT PRIMARY KEY,
            id_proveedor TEXT,
            fecha TEXT,
            importe REAL
        )
    """)

    # Tabla Ventas
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Ventas (
            id_venta TEXT PRIMARY KEY,
            fecha TEXT,
            importe REAL,
            id_cliente TEXT,
            id_empleado TEXT
        )
    """)

    conexion.commit()
    conexion.close()
    print("Tablas creadas o verificadas correctamente.")

if __name__ == "__main__":
    crear_tablas()
