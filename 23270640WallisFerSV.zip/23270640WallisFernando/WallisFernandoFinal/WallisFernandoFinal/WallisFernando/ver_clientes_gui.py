from tkinter import Label, Listbox, Scrollbar, Button, END, messagebox
from base import VentanaBase
from conexion_bd import conectar
from Clientes import VentanaClientes

class VentanaVerClientes(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Clientes Registrados - Abarrotes Wallis", siguiente_ventana)
        self.geometry("600x450")

        Label(self, text="Listado de Clientes", font=("Arial", 14, "bold")).pack(pady=10)

        scroll = Scrollbar(self)
        scroll.pack(side="right", fill="y")
        self.lista = Listbox(self, font=("Consolas", 12), yscrollcommand=scroll.set)
        self.lista.pack(padx=20, pady=10, fill="both", expand=True)
        scroll.config(command=self.lista.yview)

        # Botones de acción
        btn_frame = Label(self)
        btn_frame.pack(pady=5)
        Button(btn_frame, text="Refrescar", command=self.cargar_clientes).grid(row=0, column=0, padx=5)
        Button(btn_frame, text="Editar",    command=self._editar).grid(row=0, column=1, padx=5)
        Button(btn_frame, text="Eliminar",  command=self._eliminar).grid(row=0, column=2, padx=5)

        self.cargar_clientes()

    def cargar_clientes(self):
        self.lista.delete(0, END)
        try:
            conn = conectar()
            cur  = conn.cursor()
            cur.execute("SELECT id_cliente, nombre, telefono, direccion FROM Clientes")
            self.registros = cur.fetchall()
            conn.close()

            if not self.registros:
                self.lista.insert(END, "No hay clientes registrados.")
                return

            header = f"{'ID':<15}{'Nombre':<25}{'Teléfono':<20}{'Dirección'}"
            self.lista.insert(END, header)
            self.lista.insert(END, "-"*90)
            for c in self.registros:
                linea = f"{c[0]:<15}{c[1]:<25}{c[2]:<20}{c[3]}"
                self.lista.insert(END, linea)
        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron cargar datos:\n{e}")

    def _editar(self):
        sel = self.lista.curselection()
        if not sel or sel[0] < 2:
            messagebox.showwarning("Seleccionar", "Selecciona un cliente válido.")
            return
        idx = sel[0] - 2
        idc = self.registros[idx][0]
        self.destroy()
        VentanaClientes(None, id_cliente=idc).mainloop()

    def _eliminar(self):
        sel = self.lista.curselection()
        if not sel or sel[0] < 2:
            messagebox.showwarning("Seleccionar", "Selecciona un cliente válido.")
            return
        idx = sel[0] - 2
        idc = self.registros[idx][0]
        nombre = self.registros[idx][1]
        if not messagebox.askyesno("Confirmar", f"Eliminar cliente '{nombre}'?"):
            return
        try:
            conn = conectar()
            cur  = conn.cursor()
            cur.execute("DELETE FROM Clientes WHERE id_cliente = ?", (idc,))
            conn.commit()
            conn.close()
            messagebox.showinfo("Éxito", "Cliente eliminado.")
            self.cargar_clientes()
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo eliminar:\n{e}")

if __name__ == "__main__":
    VentanaVerClientes().mainloop()
