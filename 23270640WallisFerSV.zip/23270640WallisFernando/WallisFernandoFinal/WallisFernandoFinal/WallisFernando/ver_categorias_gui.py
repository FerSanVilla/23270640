from tkinter import Tk, Label, Listbox, Scrollbar, Button, END, messagebox
from conexion_bd import conectar
from Categorias import VentanaCategorias

class VentanaVerCategorias(Tk):
    def __init__(self):
        super().__init__()
        self.title("Categorías Registradas - Abarrotes Wallis")
        self.geometry("600x400")

        Label(self, text="Listado de Categorías", font=("Arial", 14, "bold")).pack(pady=10)

        scrollbar = Scrollbar(self)
        scrollbar.pack(side="right", fill="y")

        self.lista = Listbox(self, font=("Consolas", 12), yscrollcommand=scrollbar.set)
        self.lista.pack(padx=20, pady=10, fill="both", expand=True)

        scrollbar.config(command=self.lista.yview)

        btn_frame = Label(self)
        btn_frame.pack(pady=10)

        Button(btn_frame, text="Actualizar", command=self.cargar_categorias).grid(row=0, column=0, padx=5)
        Button(btn_frame, text="Editar", command=self.editar_categoria).grid(row=0, column=1, padx=5)
        Button(btn_frame, text="Eliminar", command=self.eliminar_categoria).grid(row=0, column=2, padx=5)

        self.cargar_categorias()

    def cargar_categorias(self):
        self.lista.delete(0, END)

        try:
            conexion = conectar()
            cursor = conexion.cursor()
            cursor.execute("SELECT id_categoria, nombre, descripcion FROM Categorias")
            self.registros = cursor.fetchall()
            conexion.close()

            if not self.registros:
                self.lista.insert(END, "No hay categorías registradas.")
                return

            header = f"{'ID':<5}{'Nombre':<20}{'Descripción'}"
            self.lista.insert(END, header)
            self.lista.insert(END, "-" * 60)

            for cat in self.registros:
                linea = f"{cat[0]:<5}{cat[1]:<20}{cat[2]}"
                self.lista.insert(END, linea)

        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron cargar los datos:\n{e}")

    def editar_categoria(self):
        index = self.lista.curselection()
        if not index or index[0] < 2:
            messagebox.showwarning("Selecciona", "Selecciona una categoría para editar.")
            return

        cat = self.registros[index[0] - 2]
        self.destroy()
        VentanaCategorias(None, id_categoria=cat[0]).mainloop()

    def eliminar_categoria(self):
        index = self.lista.curselection()
        if not index or index[0] < 2:
            messagebox.showwarning("Selecciona", "Selecciona una categoría para eliminar.")
            return

        cat = self.registros[index[0] - 2]
        confirmar = messagebox.askyesno("Confirmar", f"¿Eliminar la categoría '{cat[1]}'?")
        if not confirmar:
            return

        try:
            conexion = conectar()
            cursor = conexion.cursor()
            cursor.execute("DELETE FROM Categorias WHERE id_categoria = ?", (cat[0],))
            conexion.commit()
            conexion.close()
            self.cargar_categorias()
            messagebox.showinfo("Éxito", "Categoría eliminada.")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo eliminar:\n{e}")

if __name__ == "__main__":
    app = VentanaVerCategorias()
    app.mainloop()
